extends Enemy
class_name Koopa

const SHELL_SHAPE: RectangleShape2D = preload("res://Resources/CollisionShapes/koopa_shell.tres")

@export var slide_speed: float = 200.0
var in_a_shell: bool = false

func die() -> void:
	if defeated or in_a_shell:
		return
	in_a_shell = true
	horizontal_speed = 0.0
	contact_guard = 0.15
	animated_sprite.play("dead")
	collision_shape.set_deferred("shape", SHELL_SHAPE)
	collision_shape.set_deferred("position", Vector2(0.0, -7.0))
	set_deferred("collision_layer", 8)

func is_stationary_shell() -> bool:
	return in_a_shell and not defeated and is_zero_approx(horizontal_speed)

func is_moving_shell() -> bool:
	return in_a_shell and not defeated and not is_zero_approx(horizontal_speed)

func on_stomp(player_position: Vector2) -> void:
	if defeated:
		return
	contact_guard = 0.2
	horizontal_speed = slide_speed if player_position.x <= global_position.x else -slide_speed

func stop_shell() -> void:
	horizontal_speed = 0.0
	contact_guard = 0.2
