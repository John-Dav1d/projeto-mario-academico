extends Node

@export_range(1, 4) var phase_number: int = 1
@export_file("*.tscn") var next_phase: String = ""
@export var camera_offset: Vector2 = Vector2(0.0, -56.0)
@export var fall_margin: float = 96.0

var finished: bool = false
var final_phase: bool = false
var fall_limit: float

@onready var player: Player = $Player
@onready var camera: Camera2D = $Camera2D
@onready var tile_map: TileMap = $TileMap

func _ready() -> void:
	player.global_position = $Inicio.global_position
	var used: Rect2i = tile_map.get_used_rect()
	var size: Vector2i = tile_map.tile_set.tile_size
	camera.limit_left = int(tile_map.global_position.x + used.position.x * size.x)
	camera.limit_right = int(tile_map.global_position.x + used.end.x * size.x)
	camera.limit_top = int(tile_map.global_position.y + used.position.y * size.y - 160)
	camera.limit_bottom = int(tile_map.global_position.y + used.end.y * size.y)
	fall_limit = float(camera.limit_bottom) + fall_margin
	camera.global_position = player.global_position + camera_offset
	camera.reset_smoothing()
	$Fim.body_entered.connect(_on_finish_body_entered)
	for enemy in $Enemies.get_children():
		if enemy is Enemy:
			enemy.fall_limit = fall_limit

func _physics_process(_delta: float) -> void:
	if not player.is_dead and not finished:
		if player.global_position.y > fall_limit:
			player.die()
		var half_width: float = player.get_node("BodyCollisionShape2D").shape.size.x * 0.5
		player.global_position.x = maxf(player.global_position.x, float(camera.limit_left) + half_width)
	if final_phase and Input.is_action_just_pressed("jump"):
		Progresso.reset()
		get_tree().change_scene_to_file("res://cenas/main.tscn")

func _process(_delta: float) -> void:
	if not player.is_dead and not finished:
		camera.global_position = player.global_position + camera_offset

func _on_finish_body_entered(body: Node2D) -> void:
	if body != player or player.is_dead or finished:
		return
	finished = true
	player.controls_enabled = false
	player.velocity = Vector2.ZERO
	player.animated_sprite.pause()
	$Enemies.process_mode = Node.PROCESS_MODE_DISABLED
	_finish.call_deferred()

func _finish() -> void:
	if not next_phase.is_empty():
		Progresso.phase_start_score = Progresso.score
		get_tree().change_scene_to_file(next_phase)
	else:
		final_phase = true
		$Conclusao/Label.text = "Concluído\nPontos: %d\nW / ↑: reiniciar" % Progresso.score
		$Conclusao/Label.show()
