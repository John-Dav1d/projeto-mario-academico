extends Area2D
class_name Enemy

const POINTS_LABEL_SCENE: PackedScene = preload("res://cenas/points_label.tscn")

@export var horizontal_speed: float = -20.0
@export var fall_gravity: float = 980.0
@export var fall_limit: float = 10000.0

var vertical_speed: float = 0.0
var defeated: bool = false
var contact_guard: float = 0.0
var points_awarded: bool = false

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision_shape: CollisionShape2D = $CollisionShape2D
@onready var ground_ray: RayCast2D = $RayCast2D
@onready var wall_ray: RayCast2D = $WallRayCast2D

func _ready() -> void:
	area_entered.connect(_on_area_entered)
	animated_sprite.play("walk")

func _physics_process(delta: float) -> void:
	if defeated:
		return
	contact_guard = maxf(0.0, contact_guard - delta)
	for other in get_overlapping_areas():
		_on_area_entered(other)
		if defeated:
			return
	var half_width: float = collision_shape.shape.size.x * 0.5
	wall_ray.position = Vector2(0.0, collision_shape.position.y)
	wall_ray.target_position = Vector2(signf(horizontal_speed) * (half_width + absf(horizontal_speed) * delta + 1.0), 0.0)
	wall_ray.force_raycast_update()
	if horizontal_speed != 0.0 and wall_ray.is_colliding():
		horizontal_speed *= -1.0
	else:
		position.x += horizontal_speed * delta
	if horizontal_speed != 0.0:
		animated_sprite.flip_h = horizontal_speed > 0.0
	vertical_speed += fall_gravity * delta
	ground_ray.position = Vector2(0.0, -2.0)
	ground_ray.target_position = Vector2(0.0, maxf(4.0, vertical_speed * delta + 2.0))
	ground_ray.force_raycast_update()
	if ground_ray.is_colliding() and vertical_speed >= 0.0:
		global_position.y = ground_ray.get_collision_point().y
		vertical_speed = 0.0
	else:
		position.y += vertical_speed * delta
	if global_position.y > fall_limit:
		queue_free()

func get_stomp_y() -> float:
	return collision_shape.global_position.y - collision_shape.shape.size.y * absf(global_scale.y) * 0.5

func die() -> void:
	if defeated:
		return
	defeated = true
	horizontal_speed = 0.0
	animated_sprite.play("dead")
	collision_shape.set_deferred("disabled", true)
	get_tree().create_timer(0.5).timeout.connect(queue_free)

func die_from_hit() -> void:
	if defeated:
		return
	defeated = true
	collision_shape.set_deferred("disabled", true)
	animated_sprite.flip_v = true
	award_points()
	var start: Vector2 = position
	var death_tween: Tween = create_tween()
	death_tween.tween_property(self, "position", start + Vector2(0.0, -25.0), 0.2)
	death_tween.tween_property(self, "position", start + Vector2(0.0, 96.0), 0.5)
	death_tween.tween_callback(queue_free)

func award_points() -> void:
	if points_awarded:
		return
	points_awarded = true
	Progresso.score += 100
	var label: Label = POINTS_LABEL_SCENE.instantiate()
	label.position = global_position + Vector2(-20.0, -40.0)
	get_tree().current_scene.add_child(label)

func _on_area_entered(other: Area2D) -> void:
	if other.has_method("is_moving_shell") and other.is_moving_shell():
		die_from_hit()
