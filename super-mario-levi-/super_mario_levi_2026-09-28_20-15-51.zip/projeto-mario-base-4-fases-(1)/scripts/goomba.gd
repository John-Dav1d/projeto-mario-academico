extends Enemy
