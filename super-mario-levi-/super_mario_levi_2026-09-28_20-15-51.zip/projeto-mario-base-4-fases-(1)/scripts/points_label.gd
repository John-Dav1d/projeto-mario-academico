extends Label

func _ready() -> void:
	var label_tween: Tween = create_tween()
	label_tween.tween_property(self, "position", position + Vector2(0.0, -10.0), 0.4)
	label_tween.tween_callback(queue_free)
