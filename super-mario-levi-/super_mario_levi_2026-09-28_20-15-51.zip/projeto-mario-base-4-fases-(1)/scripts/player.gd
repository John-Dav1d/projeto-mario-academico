extends CharacterBody2D
class_name Player

signal points_scored(points: int)
signal died

enum PlayerMode { SMALL, BIG, SHOOTING }

@export var speed: float = 200.0
@export var jump_velocity: float = -480.0
@export var run_speed_damping: float = 10.0
@export var stomp_y_velocity: float = -200.0
@export var player_mode: PlayerMode = PlayerMode.SMALL

var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var is_dead: bool = false
var controls_enabled: bool = true
var previous_position: Vector2
var impact_velocity_y: float = 0.0
var invulnerability: float = 0.0

@onready var animated_sprite: PlayerAnimatedSprite = $AnimatedSprite2D
@onready var area: Area2D = $Area2D
@onready var area_shape: CollisionShape2D = $Area2D/AreaCollisionShape2D
@onready var body_shape: CollisionShape2D = $BodyCollisionShape2D

func _ready() -> void:
	previous_position = global_position
	apply_mode()
	animated_sprite.frame_changed.connect(align_sprite)
	animated_sprite.animation_changed.connect(align_sprite)
	align_sprite()
	area.area_entered.connect(handle_enemy_collision)

func _physics_process(delta: float) -> void:
	if is_dead or not controls_enabled:
		return
	previous_position = global_position
	invulnerability = maxf(0.0, invulnerability - delta)
	animated_sprite.modulate.a = 0.4 if invulnerability > 0.0 and int(invulnerability * 12.0) % 2 == 0 else 1.0
	if not is_on_floor():
		velocity.y += gravity * delta
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity
	if Input.is_action_just_released("jump") and velocity.y < 0.0:
		velocity.y *= 0.5
	var direction: float = Input.get_axis("left", "right")
	if direction != 0.0:
		velocity.x = lerpf(velocity.x, direction * speed, 1.0 - exp(-run_speed_damping * delta))
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed * 6.0 * delta)
	impact_velocity_y = velocity.y
	move_and_slide()
	animated_sprite.trigger_animation(velocity, direction, player_mode)
	for enemy in area.get_overlapping_areas():
		handle_enemy_collision(enemy)

func align_sprite() -> void:
	var texture: Texture2D = animated_sprite.sprite_frames.get_frame_texture(animated_sprite.animation, animated_sprite.frame)
	if texture:
		animated_sprite.offset = Vector2(0.0, -texture.get_height() * 0.5)

func apply_mode() -> void:
	var shape: RectangleShape2D = load("res://Resources/CollisionShapes/small_mario.tres")
	if player_mode != PlayerMode.SMALL:
		shape = load("res://Resources/CollisionShapes/big_mario.tres")
	body_shape.set_deferred("shape", shape)
	area_shape.set_deferred("shape", shape)
	body_shape.set_deferred("position", Vector2(0.0, -shape.size.y * 0.5))
	area_shape.set_deferred("position", Vector2(0.0, -shape.size.y * 0.5))
	animated_sprite.play(["small_idle", "big_idle", "shooting_idle"][player_mode])

func handle_enemy_collision(enemy: Area2D) -> void:
	if is_dead or not controls_enabled or invulnerability > 0.0:
		return
	if not enemy is Enemy or enemy.defeated or enemy.contact_guard > 0.0:
		return
	var from_above: bool = impact_velocity_y > 0.0 and previous_position.y <= enemy.get_stomp_y() + 6.0
	if enemy.has_method("is_stationary_shell") and enemy.is_stationary_shell():
		enemy.on_stomp(global_position)
		if from_above:
			velocity.y = stomp_y_velocity
		return
	if from_above:
		if enemy.has_method("is_moving_shell") and enemy.is_moving_shell():
			enemy.stop_shell()
		else:
			enemy.die()
			enemy.award_points()
			points_scored.emit(100)
		velocity.y = stomp_y_velocity
	else:
		take_damage()

func take_damage() -> void:
	if is_dead or invulnerability > 0.0:
		return
	if player_mode != PlayerMode.SMALL:
		player_mode = PlayerMode.SMALL
		invulnerability = 1.5
		apply_mode()
	else:
		die()

func die() -> void:
	if is_dead:
		return
	is_dead = true
	velocity = Vector2.ZERO
	animated_sprite.modulate.a = 1.0
	animated_sprite.play("small_death")
	area.set_deferred("monitoring", false)
	body_shape.set_deferred("disabled", true)
	died.emit()
	var start: Vector2 = position
	var death_tween: Tween = create_tween()
	death_tween.tween_property(self, "position", start + Vector2(0.0, -48.0), 0.5)
	death_tween.tween_property(self, "position", start + Vector2(0.0, 256.0), 1.0)
	death_tween.tween_callback(restart_level)

func restart_level() -> void:
	Progresso.score = Progresso.phase_start_score
	get_tree().reload_current_scene()
