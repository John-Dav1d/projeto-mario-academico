extends AnimatedSprite2D
class_name PlayerAnimatedSprite

func trigger_animation(velocity: Vector2, direction: float, player_mode: int) -> void:
	var prefix: String = ["small", "big", "shooting"][player_mode]
	if direction != 0.0:
		flip_h = direction < 0.0
	if not get_parent().is_on_floor():
		play(prefix + "_jump")
	elif direction != 0.0 and absf(velocity.x) > 5.0 and signf(velocity.x) != signf(direction):
		play(prefix + "_slide")
	elif absf(velocity.x) > 1.0:
		play(prefix + "_run")
	else:
		play(prefix + "_idle")
