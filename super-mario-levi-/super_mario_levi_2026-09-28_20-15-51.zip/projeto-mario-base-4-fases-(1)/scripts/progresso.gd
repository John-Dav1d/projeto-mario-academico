extends Node

var score: int = 0
var phase_start_score: int = 0

func reset() -> void:
	score = 0
	phase_start_score = 0
